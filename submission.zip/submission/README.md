In this Udacity project an EC2 instance on AWS was created along with Jenkins configuration, and created a pipeline to deploy a static website on S3.

The following content has been submitted according to the requirement.
- eight screenshots
- one text file containing a link to your GitHub repo

GitHub Repo link - https://github.com/MannyDhillon/static
